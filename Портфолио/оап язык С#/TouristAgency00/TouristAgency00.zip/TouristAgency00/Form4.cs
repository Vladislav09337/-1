﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace TouristAgency00
{
    public partial class Form4 : Form
    {
        // Коллекция для хранения избранных туров
        private static List<Tour> favoriteTours = new List<Tour>();

        // Список всех туров (база данных)
        private List<Tour> allTours;

        // Список отфильтрованных туров
        private List<Tour> filteredTours;

        // Панель для отображения результатов
        private FlowLayoutPanel flowLayoutPanel;

        // Класс для хранения информации о туре
        public class Tour
        {
            public int Id { get; set; }
            public string Country { get; set; }
            public string City { get; set; }
            public string HotelName { get; set; }
            public string Address { get; set; }
            public DateTime StartDate { get; set; }
            public DateTime EndDate { get; set; }
            public int DurationDays { get; set; }
            public int AvailableTours { get; set; }
            public bool IsChildTour { get; set; }
            public int HotelStars { get; set; }
            public string MealType { get; set; }
            public List<string> Services { get; set; }
            public decimal Price { get; set; }
            public int PriorityScore { get; set; } // Баллы для сортировки

            public string DatesString => $"{StartDate:dd.MM.yyyy} - {EndDate:dd.MM.yyyy}";
            public string PriceString => $"{Price:N0} ₽";
        }

        public Form4()
        {
            InitializeComponent();
            InitializeCustomComponents();
            LoadSampleTours();
            FilterAndDisplayTours();

            this.btnSearch.Click += BtnSearch_Click;
            this.btnTop.Click += BtnTop_Click;
        }

        private void InitializeCustomComponents()
        {
            // Создаем FlowLayoutPanel для отображения туров
            flowLayoutPanel = new FlowLayoutPanel();
            flowLayoutPanel.Location = new System.Drawing.Point(12, 210);
            flowLayoutPanel.Size = new System.Drawing.Size(760, 450);
            flowLayoutPanel.AutoScroll = true;
            flowLayoutPanel.FlowDirection = FlowDirection.TopDown;
            flowLayoutPanel.WrapContents = false;
            this.Controls.Add(flowLayoutPanel);

            // Изменяем размер формы
            this.Size = new System.Drawing.Size(800, 720);
            groupBox1.Visible = false;
            label1.Location = new System.Drawing.Point(300, 180);
        }

        private void LoadSampleTours()
        {
            allTours = new List<Tour>();
            var random = new Random();

            // Турция
            allTours.Add(new Tour
            {
                Id = 1,
                Country = "Турция",
                City = "Анталия",
                HotelName = "Rixos Premium Belek",
                Address = "Belek Mahallesi, 07500",
                StartDate = new DateTime(2026, 7, 15),
                EndDate = new DateTime(2026, 7, 22),
                DurationDays = 7,
                AvailableTours = 5,
                IsChildTour = true,
                HotelStars = 5,
                MealType = "Всё включено",
                Services = new List<string> { "SPA", "WiFi", "Спорт", "Трансфер" },
                Price = 85000,
                PriorityScore = 95
            });

            allTours.Add(new Tour
            {
                Id = 2,
                Country = "Турция",
                City = "Кемер",
                HotelName = "Maxx Royal Kemer",
                Address = "Göynük Mahallesi, 07980",
                StartDate = new DateTime(2026, 7, 16),
                EndDate = new DateTime(2026, 7, 23),
                DurationDays = 7,
                AvailableTours = 3,
                IsChildTour = true,
                HotelStars = 5,
                MealType = "Всё включено",
                Services = new List<string> { "SPA", "WiFi", "VIP", "Кондиционер" },
                Price = 120000,
                PriorityScore = 98
            });

            // Египет
            allTours.Add(new Tour
            {
                Id = 3,
                Country = "Египет",
                City = "Хургада",
                HotelName = "Steigenberger Aqua Magic",
                Address = "Sahl Hasheesh Road",
                StartDate = new DateTime(2026, 8, 10),
                EndDate = new DateTime(2026, 8, 17),
                DurationDays = 7,
                AvailableTours = 8,
                IsChildTour = true,
                HotelStars = 4,
                MealType = "Всё включено",
                Services = new List<string> { "SPA", "WiFi", "Спорт" },
                Price = 65000,
                PriorityScore = 88
            });

            allTours.Add(new Tour
            {
                Id = 4,
                Country = "Египет",
                City = "Шарм-эль-Шейх",
                HotelName = "Four Seasons Resort",
                Address = "Sharks Bay, 99999",
                StartDate = new DateTime(2026, 8, 12),
                EndDate = new DateTime(2026, 8, 19),
                DurationDays = 7,
                AvailableTours = 2,
                IsChildTour = false,
                HotelStars = 5,
                MealType = "Полупансион",
                Services = new List<string> { "SPA", "WiFi", "VIP" },
                Price = 150000,
                PriorityScore = 92
            });

            // Греция
            allTours.Add(new Tour
            {
                Id = 5,
                Country = "Греция",
                City = "Крит",
                HotelName = "Creta Maris Beach Resort",
                Address = "Hersonissos, 70014",
                StartDate = new DateTime(2026, 7, 20),
                EndDate = new DateTime(2026, 7, 27),
                DurationDays = 7,
                AvailableTours = 4,
                IsChildTour = true,
                HotelStars = 4,
                MealType = "Полупансион",
                Services = new List<string> { "WiFi", "Спорт", "Кондиционер" },
                Price = 78000,
                PriorityScore = 85
            });

            // Кипр
            allTours.Add(new Tour
            {
                Id = 6,
                Country = "Кипр",
                City = "Айя-Напа",
                HotelName = "Grecian Bay Hotel",
                Address = "Kryou Nerou 32",
                StartDate = new DateTime(2026, 7, 18),
                EndDate = new DateTime(2026, 7, 25),
                DurationDays = 7,
                AvailableTours = 6,
                IsChildTour = false,
                HotelStars = 3,
                MealType = "Завтрак",
                Services = new List<string> { "WiFi", "Кондиционер" },
                Price = 55000,
                PriorityScore = 75
            });

            // Таиланд
            allTours.Add(new Tour
            {
                Id = 7,
                Country = "Таиланд",
                City = "Пхукет",
                HotelName = "The Shore at Katathani",
                Address = "Kata Beach, 83100",
                StartDate = new DateTime(2026, 12, 5),
                EndDate = new DateTime(2026, 12, 12),
                DurationDays = 7,
                AvailableTours = 3,
                IsChildTour = true,
                HotelStars = 5,
                MealType = "Всё включено",
                Services = new List<string> { "SPA", "WiFi", "VIP", "Трансфер" },
                Price = 180000,
                PriorityScore = 96
            });
        }

        private void FilterAndDisplayTours()
        {
            // Получаем данные из Form1
            int requiredDays = Form1.Days;
            DateTime startPeriod = Form1.PeriodStart;
            DateTime endPeriod = Form1.PeriodEnd;
            int peopleCount = Form1.PeopleCount;
            bool hasChildren = Form1.HasChildren;

            // Получаем данные из Form3 (если шаг не пропущен)
            int requiredStars = Form3.HotelStars;
            string requiredMeal = Form3.MealType;
            List<string> requiredServices = Form3.SelectedServices;
            int minPrice = Form3.MinPrice;
            int maxPrice = Form3.MaxPrice;

            // Фильтрация туров
            filteredTours = allTours.Where(tour =>
                tour.DurationDays == requiredDays &&
                tour.StartDate >= startPeriod && tour.EndDate <= endPeriod &&
                tour.AvailableTours >= peopleCount &&
                (!hasChildren || tour.IsChildTour) &&
                (requiredStars == 0 || tour.HotelStars >= requiredStars) &&
                (requiredMeal == "Не имеет значения" || tour.MealType == requiredMeal) &&
                tour.Price >= minPrice && tour.Price <= maxPrice &&
                requiredServices.All(service => tour.Services.Contains(service))
            ).ToList();

            // Сортировка по приоритету (баллам) от высокого к низкому
            filteredTours = filteredTours.OrderByDescending(t => t.PriorityScore).ToList();

            // Отображение результатов
            DisplayTours();
        }

        private void DisplayTours()
        {
            flowLayoutPanel.Controls.Clear();

            if (filteredTours.Count == 0)
            {
                Label noResults = new Label();
                noResults.Text = "По вашему запросу туров не найдено.\nИзмените параметры поиска.";
                noResults.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
                noResults.ForeColor = System.Drawing.Color.Gray;
                noResults.AutoSize = true;
                noResults.Location = new System.Drawing.Point(20, 20);
                flowLayoutPanel.Controls.Add(noResults);
                return;
            }

            foreach (var tour in filteredTours)
            {
                flowLayoutPanel.Controls.Add(CreateTourCard(tour));
            }
        }

        private Panel CreateTourCard(Tour tour)
        {
            Panel card = new Panel();
            card.Size = new System.Drawing.Size(740, 180);
            card.BorderStyle = BorderStyle.FixedSingle;
            card.Margin = new Padding(0, 0, 0, 10);
            card.BackColor = System.Drawing.Color.White;

            // Название отеля и звёзды
            Label lblHotel = new Label();
            lblHotel.Text = $"{tour.HotelName} {new string('★', tour.HotelStars)}";
            lblHotel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            lblHotel.Location = new System.Drawing.Point(10, 10);
            lblHotel.Size = new System.Drawing.Size(500, 25);

            // Страна и город
            Label lblLocation = new Label();
            lblLocation.Text = $"{tour.Country}, {tour.City}";
            lblLocation.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            lblLocation.Location = new System.Drawing.Point(10, 40);
            lblLocation.Size = new System.Drawing.Size(300, 20);

            // Адрес
            Label lblAddress = new Label();
            lblAddress.Text = $"Адрес: {tour.Address}";
            lblAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            lblAddress.ForeColor = System.Drawing.Color.Gray;
            lblAddress.Location = new System.Drawing.Point(10, 65);
            lblAddress.Size = new System.Drawing.Size(500, 20);

            // Даты тура
            Label lblDates = new Label();
            lblDates.Text = $"Даты: {tour.DatesString} ({tour.DurationDays} дней)";
            lblDates.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            lblDates.Location = new System.Drawing.Point(10, 90);
            lblDates.Size = new System.Drawing.Size(300, 20);

            // Питание и услуги
            string servicesStr = tour.Services.Count > 0 ? string.Join(", ", tour.Services) : "Без услуг";
            Label lblServices = new Label();
            lblServices.Text = $"Питание: {tour.MealType} | Услуги: {servicesStr}";
            lblServices.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            lblServices.Location = new System.Drawing.Point(10, 115);
            lblServices.Size = new System.Drawing.Size(550, 20);

            // Доступно туров
            Label lblAvailable = new Label();
            lblAvailable.Text = $"Доступно туров: {tour.AvailableTours}";
            lblAvailable.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            lblAvailable.ForeColor = System.Drawing.Color.Green;
            lblAvailable.Location = new System.Drawing.Point(10, 140);
            lblAvailable.Size = new System.Drawing.Size(200, 20);

            // Цена
            Label lblPrice = new Label();
            lblPrice.Text = tour.PriceString;
            lblPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold);
            lblPrice.ForeColor = System.Drawing.Color.DarkRed;
            lblPrice.Location = new System.Drawing.Point(550, 40);
            lblPrice.Size = new System.Drawing.Size(150, 30);
            lblPrice.TextAlign = System.Drawing.ContentAlignment.MiddleRight;

            // Кнопка "Забронировать"
            Button btnBook = new Button();
            btnBook.Text = "Забронировать";
            btnBook.BackColor = System.Drawing.Color.LightGreen;
            btnBook.Size = new System.Drawing.Size(120, 35);
            btnBook.Location = new System.Drawing.Point(550, 90);
            btnBook.Tag = tour;
            btnBook.Click += BtnBook_Click;

            // Кнопка "В избранное"
            Button btnFavorite = new Button();
            bool isFavorite = favoriteTours.Any(t => t.Id == tour.Id);
            btnFavorite.Text = isFavorite ? "★ В избранном" : "☆ В избранное";
            btnFavorite.BackColor = System.Drawing.Color.LightYellow;
            btnFavorite.Size = new System.Drawing.Size(120, 35);
            btnFavorite.Location = new System.Drawing.Point(550, 135);
            btnFavorite.Tag = tour;
            btnFavorite.Click += BtnFavorite_Click;

            card.Controls.Add(lblHotel);
            card.Controls.Add(lblLocation);
            card.Controls.Add(lblAddress);
            card.Controls.Add(lblDates);
            card.Controls.Add(lblServices);
            card.Controls.Add(lblAvailable);
            card.Controls.Add(lblPrice);
            card.Controls.Add(btnBook);
            card.Controls.Add(btnFavorite);

            return card;
        }

        private void BtnBook_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            Tour tour = btn.Tag as Tour;
            MessageBox.Show($"Вы забронировали тур:\n{tour.Country}, {tour.City}\nОтель: {tour.HotelName}\nДаты: {tour.DatesString}\nСтоимость: {tour.PriceString}\n\nСпасибо за покупку!",
                "Бронирование", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void BtnFavorite_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            Tour tour = btn.Tag as Tour;

            if (favoriteTours.Any(t => t.Id == tour.Id))
            {
                favoriteTours.RemoveAll(t => t.Id == tour.Id);
                btn.Text = "☆ В избранное";
                MessageBox.Show($"Тур \"{tour.HotelName}\" удалён из избранного", "Избранное", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                favoriteTours.Add(tour);
                btn.Text = "★ В избранном";
                MessageBox.Show($"Тур \"{tour.HotelName}\" добавлен в избранное", "Избранное", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void BtnSearch_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form1 = new Form1();
            form1.ShowDialog();
            this.Close();
        }

        private void BtnTop_Click(object sender, EventArgs e)
        {
            if (favoriteTours.Count == 0)
            {
                MessageBox.Show("Список избранных туров пуст", "Избранное", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // Показать избранные туры
            string favoriteList = "Избранные туры:\n\n";
            foreach (var tour in favoriteTours)
            {
                favoriteList += $"• {tour.Country}, {tour.City} - {tour.HotelName} - {tour.PriceString}\n";
            }
            MessageBox.Show(favoriteList, "Избранное", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
        }
    }
}