﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void cbCities_SelectedIndexChanged(object sender, EventArgs e)
        {
            string city = cbCities.SelectedItem.ToString();
            switch (city)
            {
                case "Москва":
                    tbInfo.Text = "Население: -13 млн. Достопримечательность: Кремль.";
                    break;
                case "Санкт-Петербург":
                    tbInfo.Text = "Население: -5,6 млн. Достопримечательность: Эрмитаж.";
                    break;
                case "Казань":
                    tbInfo.Text = "Население: -1,3 млн. Достопримечательность: Казанский кремль.";
                    break;
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            cbCities.Items.Add("Москва");
            cbCities.Items.Add("Санкт-Петербург");
            cbCities.Items.Add("Казань");
            cbCities.SelectedIndex = 0;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            tbInfo.Clear();
            tbInfo.Focus();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(tbInfo.Text))
            {
                cbCities.Items.Add(tbInfo.Text);
                cbCities.SelectedIndex = cbCities.Items.Count - 1;
            }
            else
            {
                MessageBox.Show("Введите текст в поле tbInfo для добавления в список.", "Предупреждение");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tbInfo.Text))
            {
                MessageBox.Show("Введите текст в поле textBox1 для вставки.", "Предупреждение");
                return;
            }

            if (cbCities.SelectedIndex >= 0)
            {
                cbCities.Items.Insert(cbCities.SelectedIndex, cbCities.Text);
            }
            else
            {
                MessageBox.Show("Выделите позицию в списке cbCities для вставки.", "Предупреждение");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (cbCities.SelectedIndex >= 0)
            {
                cbCities.Items.RemoveAt(cbCities.SelectedIndex);

                // Если после удаления остались элементы, выделяем первый
                if (cbCities.Items.Count > 0)
                {
                    cbCities.SelectedIndex = 0;
                }
            }
            else
            {
                MessageBox.Show("Выделите позицию в списке cbCities для удаления.", "Предупреждение");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (cbCities.SelectedItem != null)
            {
                // Копируем текст выделенного элемента в listBox
                listBox1.Items.Add(cbCities.SelectedItem.ToString());

                // Автоматически прокручиваем listBox к последнему элементу
                listBox1.TopIndex = listBox1.Items.Count - 1;

                // Можно также выделить добавленный элемент
                // listBox1.SelectedIndex = listBox1.Items.Count - 1;
            }
            else
            {
                MessageBox.Show("Выделите позицию в списке comboBox1 для копирования.", "Предупреждение");
            }
        }
    }
}